 
function showMyImage(fileInput) {
			        var files = fileInput.files;
			        for (var i = 0; i < files.length; i++) {           
			            var file = files[i];
			            var imageType = /image.*/;     
			            if (!file.type.match(imageType)) {
			                continue;
			            }           
			            var img=document.getElementById("thumbnail");            
			            img.file = file;    
			            var reader = new FileReader();
			            reader.onload = (function(aImg) { 
			                return function(e) { 
			                    aImg.src = e.target.result; 
			                }; 
			            })(img);
			            reader.readAsDataURL(file);
			        }    
			    }
 
 function validateStudent(){
	    
	 		//Validating Register Number
			 var regNum = document.registrationForm.regNo.value;
			 
				//Validating Student Name			 
				var sname = document.registrationForm.stuName.value;
			
				//Validating Department Name	 
				var dname = document.registrationForm.deptName.value;
				
				//Validating Image
				var image = document.registrationForm.image.value;
			 
			 if(regNum==null || regNum=="" || regNum.trim().length==0){
				 
				 document.getElementById("regno").innerHTML="Register Number must be Provided";
				 
				 return false;
			 }
			 if(regNum!=null && regNum.trim().length>0){
				 
				 document.getElementById("regno").innerHTML="";
				 
			 }
			 if(isNaN(regNum)){
				 
				 document.getElementById("regno").innerHTML="Register Number must be a Number";
				 
				 return false;
			 }
			 if(!isNaN(regNum)){
				 
				 document.getElementById("regno").innerHTML="";
				 
			 }
			 if(sname==null || sname=="" || sname.trim().length==0){
				 
				 document.getElementById("stuname").innerHTML = "Student Name must be Provided";
				 
				 return false;
			 }
			 if(sname!=null && sname.trim().length>0){
				 
				 document.getElementById("stuname").innerHTML = "";
				
			 }
			 if(dname==null || dname=="" || dname.trim().length==0){
						 
				document.getElementById("deptname").innerHTML = "Department Name must be Provided";
						 
				return false;
			}
			if(dname!=null && dname.trim().length>0){
				 
				document.getElementById("deptname").innerHTML = "";
				
			 }
			if(image==null || image=="" || image.trim().length==0){
				 
				document.getElementById("image").innerHTML = "Please Choose an Image to Upload";
						 
				return false;
			}
			if(image!=null){
				 
				document.getElementById("image").innerHTML = "";
				 
			 }
						 
 }
 
 function studentRegnoValidation(){
	 
	 	var regNum = document.registrationForm.regNo.value;
	 	
	 	 if(regNum==null || regNum=="" || regNum.trim().length==0){
			 
			 document.getElementById("regno").innerHTML="Register Number must be Provided";
			 
		 }
	 	 else if(regNum!=null && regNum.trim().length>0){
				 
				 document.getElementById("regno").innerHTML="";
				 
	 	 }
	 	 
		
}
 function studentNameValidation(){
	 

	 	var sname = document.registrationForm.stuName.value;
	 	
	 	 if(sname==null || sname=="" || sname.trim().length==0){
			 
			 document.getElementById("stuname").innerHTML = "Student Name must be Provided";
			 
		 }
	 	 else  if(sname!=null && sname.trim().length>0){
			 
			 document.getElementById("stuname").innerHTML = "";
			
		 }
	 	 
	 
 }
 function studentDeptValidation(){
	 
	 var dname = document.registrationForm.deptName.value;
 	 
 	 if(dname==null || dname=="" || dname.trim().length==0){
		 
			document.getElementById("deptname").innerHTML = "Department Name must be Provided";
					 
		}
 	 else if(dname!=null && dname.trim().length>0){
			 
			document.getElementById("deptname").innerHTML = "";
			document.registrationForm.deptName.value=dname.toUpperCase();
			 
		 }
 		 
 }
 
 function studentImageValidation(){
	 

		var image = document.registrationForm.image.value;
		
		if(image==null || image=="" || image.trim().length==0){
			 
			document.getElementById("image").innerHTML = "Please Choose an Image to Upload";
					 
		}
		else if(image!=null){
			 
			document.getElementById("image").innerHTML = "";
			 
		 }
		
	 
 }
 