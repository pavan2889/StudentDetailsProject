package com.student.controller;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.student.dto.Student;
import com.student.service.StudentService;
import com.student.service.StudentServiceImpl;

@WebServlet("/registration.do")
@MultipartConfig(maxFileSize = 16177215)
public class StudentRegistration extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	StudentService service = new StudentServiceImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("stuName");
		
		String regno = request.getParameter("regNo");
		
		String dept = request.getParameter("deptName");
		
		Part part = request.getPart("image");
		
		InputStream inputStream = part.getInputStream();
		
		Student student = new Student();
		student.setRegisterNum(regno);
		student.setStudentName(name);
		student.setDeptName(dept);
		student.setImage(inputStream);
		
		int  count = service.registerStudent(student);
		
		if(count==1){
			request.setAttribute("status","Student Successfully Registered...!!!");
		}
		else{
			request.setAttribute("status", "Student Registration Failed...!!!");
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("registerStatus.jsp");
		
		dispatcher.forward(request, response);
		
	}

}
