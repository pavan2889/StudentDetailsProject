package com.student.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.student.dto.Student;
import com.student.service.StudentService;
import com.student.service.StudentServiceImpl;

@WebServlet("/searchingStudent.do")
public class StudentSearching extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	StudentService service = new StudentServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String regNo = request.getParameter("regNo");
		String stuName = request.getParameter("stuName");
		String deptName = request.getParameter("deptName");
		
		Student student = new Student();
		
		student.setRegisterNum(regNo);
		student.setStudentName(stuName);
		student.setDeptName(deptName);
		
		List<Student> list = service.searchStudents(student);
		
		request.setAttribute("studentsList", list);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/studentDetails.jsp");
		dispatcher.forward(request, response);
				
	}

}
