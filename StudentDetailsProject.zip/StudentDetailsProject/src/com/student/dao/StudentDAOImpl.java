package com.student.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.student.dto.Student;
import com.student.util.SqlConstants;

public class StudentDAOImpl implements StudentDAO{

	@Override
	public int registerStudent(Student student) {
		
		int count = 0;
		InputStream inputStream  = null;
		
			try {
				
				Connection connection = ConnectionFactory.getConnection();
				
				PreparedStatement prepStatement= connection.prepareStatement(SqlConstants.INSERT_STUDENT);
				prepStatement.setString(1, student.getRegisterNum());
				prepStatement.setString(2, student.getStudentName());
				prepStatement.setString(3, student.getDeptName());
				inputStream = student.getImage();
				prepStatement.setBinaryStream(4, inputStream,inputStream.available());
				count = prepStatement.executeUpdate();
				
			} catch (SQLException | IOException e) {
				e.printStackTrace();
			}
			
		return count;
	}

	@Override
	public List<Student> searchStudents(Student student) {
		
		//Generating the query
		boolean flag = false;
		StringBuilder builder = new StringBuilder("select * from student_details");
		if(student.getRegisterNum()!=null && student.getRegisterNum().trim().length()>0){
			builder.append(" where regno = '"+student.getRegisterNum()+"'");
			flag=true;
		}
		if(student.getStudentName()!=null && student.getStudentName().trim().length()>0){
			if(flag){
				builder.append(" and sname = '"+student.getStudentName()+"'");
			}
			else{
				builder.append(" where sname = '"+student.getStudentName()+"'");
				flag=true;
			}
		}
		if(student.getDeptName()!=null && student.getDeptName().trim().length()>0){
			if(flag){
				builder.append(" and deptname = '"+student.getDeptName()+"'");
			}
			else{
				builder.append(" where deptname = '"+student.getDeptName()+"'");
			}
		}
		//
		
		List<Student> list = new ArrayList<Student>();
		
		try {
			
			Connection connection = ConnectionFactory.getConnection();
			PreparedStatement preparedStatement= connection.prepareStatement(builder.toString());
			ResultSet resultSet = preparedStatement.executeQuery();

			while(resultSet.next()){
				
				Student stu = new Student();
				stu.setRegisterNum(resultSet.getString("regno"));
				stu.setStudentName(resultSet.getString("sname"));
				stu.setDeptName(resultSet.getString("deptname"));
				
				list.add(stu);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			
		}
		
		return list;
	}
	
	}