package com.student.dao;

import java.util.List;

import com.student.dto.Student;

public interface StudentDAO{
	
		public int registerStudent(Student student);
		
		public List<Student> searchStudents(Student student);
		
}
