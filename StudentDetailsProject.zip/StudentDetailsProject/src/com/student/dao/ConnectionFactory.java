package com.student.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	private static Connection connection=null;
	static{
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:pavan","hibernate","hibernate");
			} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
	}
	
	public static Connection getConnection(){
		return connection;
	}
	
}
