package com.student.service;

import java.util.List;

import com.student.dto.Student;

public interface StudentService {
	
	public int registerStudent(Student student);
	
	public List<Student> searchStudents(Student student);
	
}
