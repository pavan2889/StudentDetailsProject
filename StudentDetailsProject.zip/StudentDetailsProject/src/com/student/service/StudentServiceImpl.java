package com.student.service;

import java.util.List;

import com.student.dao.StudentDAO;
import com.student.dao.StudentDAOImpl;
import com.student.dto.Student;

public class StudentServiceImpl implements StudentService {

	StudentDAO studentDAO = new StudentDAOImpl();

	@Override
	public int registerStudent(Student student) {

		int i = 0;

		i = studentDAO.registerStudent(student);

		return i;

	}

	@Override
	public List<Student> searchStudents(Student student) {

		List<Student> list = studentDAO.searchStudents(student);
		
		return list;
	}

}
