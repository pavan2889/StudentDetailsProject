package com.student.util;

public class SqlConstants {
	
	public  static final String IMG_RETRIEVE="select image from student_details where regno = ?";
	
	public static final String INSERT_STUDENT="insert into student_details(regno,sname,deptname,image) values(?,?,?,?)";
	

}
